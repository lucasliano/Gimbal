

//------------Defines--------------------
#define BUFFER_SIZE 10


//-----------Estados--------------------
#define ESPERANDO_INICIO 0
#define ESPERANDO_TIPO 1
#define RECIBIENDO_DATOS 2


//------------Funciones------------------

void actualizarPosBuffer(int* );
void Maquina_TransDatos();
