#include "PWM.h"

void Init_GPIO_PWM(void);
void UpdatePWM(void);
