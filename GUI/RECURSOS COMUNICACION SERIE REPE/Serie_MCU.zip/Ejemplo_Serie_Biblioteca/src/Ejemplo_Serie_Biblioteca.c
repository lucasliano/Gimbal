/*
===============================================================================
 Name        : Ejemplo_Serie_Biblioteca.c
 Author      : Fede Bua
 Date     : Jul/2019
 Description : Al apretar SW1 o SW2 transmite mensajes y con SW3 permite el reenvío de estos.
 	 	 	 	 En la recepción, retransmite los últimos 10 caracteres recibidos
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "funciones.h"



int main()
{
	uint8_t com = 0; //UART0
	int16_t exitoTx;
	static uint8_t primeraVezB0=0, primeraVezB1=0;

	int i = 0;
	int16_t datoRx;
	char buffer[10];


	inicializar();
	LedsRGB (0, 0);
	LedsRGB (1, 0);
	LedsRGB (2, 0);

	while(1)
	{

		/*========================TRANSMISIÓN=====================================*/
		uint8_t estadoBoton0=consultar(KEY0); //Botón TX
		uint8_t estadoBoton1=consultar(KEY1); //Botón TX
		uint8_t estadoBoton2=consultar(KEY2); //Botón Reset

		if(estadoBoton0==APRETADO && primeraVezB0==0)
		{
			exitoTx = Transmitir (com, (const void *) "Boton 0",  sizeof(char) * 7 );	//Envía 7 caracteres (sin '\0')
			if(exitoTx!=-1)
				primeraVezB0=1;	//Evita rebote del botón para enviar el mensaje una sola vez
		}

		if(estadoBoton1==APRETADO && primeraVezB1==0)
		{//Recorta el mensaje enviado a 11 caracteres (Boton 1 apr)
			exitoTx=Transmitir (com, (const void *) "Boton 1 apretado" ,  sizeof(char) * 11 );
			if(exitoTx!=-1)
			{
				primeraVezB1=1;
				LedsRGB (0, 1);
			}
		}
		if(estadoBoton2==APRETADO)
		{
			primeraVezB0=0; //Reseteo variables de botones
			primeraVezB1=0;
			LedsRGB (0, 0);
		}

		/*===========================RECEPCIÓN=============================*/
		datoRx = UART0_PopRX(); //Primitiva similar a "GetDato();"
		if(datoRx!= -1) //En caso de que haya un dato
		{
			LedsRGB (1, 1);
			buffer[i]=datoRx;


			/**
				if(i>=10 || buffer[i-1] == '\n')
			{ //Retransmito lo recibido cuando se llene el buffer circular
				exitoTx = Transmitir (com, (void *) buffer,  sizeof(int16_t) * i );
				i=0;
			}**/
			exitoTx = Transmitir (com, (void *) buffer,  sizeof(char) * i );
			i++;
		}

	}
	return 0;
}
