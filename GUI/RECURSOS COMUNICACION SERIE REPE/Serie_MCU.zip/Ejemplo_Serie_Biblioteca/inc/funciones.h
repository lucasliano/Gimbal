/*
 * funciones.h
 *
 *  Created on: 10 jul. 2019
 *      Author: Federico
 */

#ifndef FUNCIONES_H_
#define FUNCIONES_H_

#include <bibliotecaInfoII.h>
void inicializar (void);
uint8_t consultar (uint8_t,uint8_t);

#define APRETADO 1
#define SOLTADO 0

#define		KEY0			PORT2,10
#define		KEY1			PORT0,18
#define		KEY2			PORT0,11
#define		KEY3			PORT2,13

#endif /* FUNCIONES_H_ */
