/**
  \file i2c.h
  \brief Declaración de rutinas, defines y direcciones de memoria asociados al manejo de registros i2c.
  \author Grupo 8 - R2003
  \date 2019.10.19
  \version 1.2
*/

