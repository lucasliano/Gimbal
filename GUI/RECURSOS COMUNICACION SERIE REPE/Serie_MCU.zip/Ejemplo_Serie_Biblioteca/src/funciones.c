/*
 * inic.c
 *
 *  Created on: 10 jul. 2019
 *      Author: Federico
 */
#include "funciones.h"
void inicializar(void)
{
	Inicializacion();
	InicializarTeclado(); //Inicializo teclas del Infotronic
}

uint8_t consultar (uint8_t puerto, uint8_t pin)
{
	return GetPIN(puerto,pin, BAJO); //BAJO hace referencia a si el teclado es activo bajo o alto (Teclas del infotronic son activo bajo, es decir, están apretadas cuando al pin del LPC le llega un 0)
}
