/**
  \file i2c.c
  \brief Se encuentran las rutinas de manejo de i2c a nivel de drivers.
  \author Grupo 8 - R2003
  \date 2019.10.19
  \version 1.2
*/


